@extends("layouts.backend.master")

@section('maincontent')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<section class="content">
<div class="container-fluid">
<div class="row">
  <section class="col-lg-12 connectedSortable">
  <div class="card direct-chat direct-chat-primary">
    <div class="flex-container">
  <div class="flex-item-left"><h5>Emp Attendence</h5></div>
  <!-- <div class="flex-item-right"><a href="#"><button class="btn btn-success add_holiday"><span class="fa fa-plus"></span> Add Holiday</button></a></div> -->
</div>

@if(Session::get('success'))
<div class="alert alert-success" role="alert">
  {{ Session::get('success') }}
</div>
@endif
</div>
</section>
<div id="overlay">
  <div class="cv-spinner">
    <span class="spinner"></span>
  </div>
</div>
<section class="col-lg-12 connectedSortable">
<div class="card direct-chat direct-chat-primary">
<!-- /.content -->
<div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th style="min-width: 70px">SL No.</th>
                                  
                                    <th>Employee</th>
                                    <?php 


                                    ?>

                                  @for ($i = 1; $i <= $num_of_days; $i++)
                                      <th>{{$i}}</th>
                                  @endfor 
                                </tr>
                            </thead>
                            <tbody>
                            
                               


                                    @foreach ($user_login_data as $row=>$col)
                                    <?php 
                                 $user_id=$row;
                   $user=DB::table('users')->where('id',$user_id)->first();                
                                    ?>
                                       
                                        <tr>
                                            <td></td>
                                            <td>{{$user->name}}</td>
                            @for ($i = 1; $i <= $num_of_days; $i++)
                            <?php 
                            $num_days=sprintf('%02d', $i);
$date_print=date("$full_year-$month-$num_days");
$day=date("l",strtotime($date_print));
$day_check=DB::table('weekoffs')->where('week_day',$day)->first();
$holidays_check=DB::table('holidays')->where('date',$date_print)->first();

$login_datas=DB::table('user_logins')->where('user_id',$user_id)->whereDate('login_date','=',$date_print)->get();



$user_data_extra=DB::table('user_extra_details')->where('store_id',$user_id)->first(); 
     $shift_data=DB::table('h_r_m_s_shifts')->where('id',$user_data_extra->shift_id)->first(); 
    $time=0;

foreach($login_datas as $login_data)
{
$start_time=strtotime($shift_data->login_time)-(int)$shift_data->login_variance*60;
$end_time=strtotime($shift_data->logout_time)+(int)$shift_data->login_variance*60;
if(strtotime($login_data->login_time)>=$start_time && strtotime($login_data->logout_time)<=$end_time)
{
$loginTime = strtotime($login_data->login_time);
if($login_data->logout_time!='')
{
$logoutTime = strtotime($login_data->logout_time);
$diff_time = (float)$logoutTime - (float)$loginTime;
  
$time=(float)$time+(float)$diff_time;    
}
}


}
$total_login_time=gmdate("H:i:s", $time);
                            ?>
                                               
                                          @if($day_check!='')
                                          <td class="text-danger">{{$day}}</td>
                                          @elseif($holidays_check!='')
                                          <td class="text-primary">{{$holidays_check->holiday}}</td>
                                          @elseif($date_print>date('Y-m-d'))
                                          <td><i class="fa fa-times text-danger"></td>
                 
                                          @else
                                          @if($time==0)
  <td id="1"><i class="fa fa-d text-danger"> A</td>
                                          @elseif($time<=14400)
  <td id="1"><i class="fa fa-check text-info">{{$total_login_time}}H/L</td>
                                          @else
                                          <td id="1"><i class="fa fa-check text-success">{{$total_login_time}}</td>
                                            @endif 
                                          @endif       
                                         
                                                  
    
                                              
                                                
                                            @endfor
                                           
                                        </tr>

                                    @endforeach
                            </tbody>
                        </table>
                    </div>










<!-- /.content -->
</div>
</section>

</div>

</div>
</section>

</div>
//
<div class="modal fade" id="session_modal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Holidays</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="session_modal">
         
        </div>
        
        <!-- Modal footer -->
       
        
      </div>
    </div>
  </div>
  
@endsection
@section('custom_js')
<script type="text/javascript">
    //
// $(document).on("click",".remove",function(){
//    var r = confirm("Are you sure ?");

     
//        if (r === false) {
//            return false;
//         }
// })
  //
   //
     $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
     //



    
$(document).ready(function(){

})

  //
  function get_data($statesave)
{



if ($.fn.DataTable.isDataTable('.yajra-datatable')) {
   $('.yajra-datatable').DataTable().destroy()
}

     var table = $('.yajra-datatable').DataTable({
        processing: true,
        serverSide: true,
        stateSave: $statesave,
        ajax: {
        url: "{{ route('get_holiday') }}",
         data: {a:'2'},
    },
       
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'date', name: 'date'},
            {data: 'holiday', name: 'holiday'},
            {data: 'holiday_type', name: 'holiday_type'},
          
            {
                data: 'action', 
                name: 'action', 
                orderable: true, 
                searchable: true
            },
        ]
    });   
}
 
</script>

@endsection